from flask import Flask, flash, render_template, redirect, url_for
from flask_migrate import Migrate
from config import DevConfig
from sqlalchemy import func, desc
from forms import CommentForm
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from models import db, Post, Tag, tags, Comment, User

def create_app():
    app = Flask(__name__)
    app.config.from_object(DevConfig)

    db.init_app(app)
    migrate = Migrate(app, db)
    admin = Admin(app)

    ################## helping functions ###################################
    def sidebar_data():
        recent = Post.query.order_by(Post.publish_date.desc()).limit(5).all()
        top_tags = db.session.query(
            Tag, func.count(tags.c.post_id).label('total')
        ).join(tags).group_by(Tag).order_by(desc('total')).limit(5).all()

        return recent, top_tags
    ######################################################################

    @app.route('/')
    @app.route('/<int:page>')
    def home(page=1):
        posts = Post.query.order_by(Post.publish_date.desc()).paginate(page=page, per_page=app.config.get('POSTS_PER_PAGE', 10), error_out=False)
        recent, top_tags = sidebar_data()

        return render_template(
            'home.html',
            posts=posts,
            recent=recent,
            top_tags=top_tags
        )

    @app.route('/post/<int:post_id>', methods=('GET', 'POST'))
    def post(post_id):
        form = CommentForm()
        if form.validate_on_submit():
            new_comment = Comment()
            new_comment.name = form.name.data
            new_comment.text = form.text.data
            new_comment.post_id = post_id
            try:
                db.session.add(new_comment)
                db.session.commit()
            except Exception as e:
                flash("Error adding your comment: %s" % str(e), 'error')
                db.session.rollback()
            else:
                flash('Comment added', 'info')
            return redirect(url_for('post', post_id=post_id))
        post = Post.query.get_or_404(post_id)
        tags = post.tags
        comments = post.comments.order_by(Comment.date.desc()).all()
        recent, top_tags = sidebar_data()
        return render_template('post.html', post=post, tags=tags, comments=comments, recent=recent, top_tags=top_tags, form=form)

    @app.route('/posts_by_user/<string:username>', methods=["GET"])
    def posts_by_user(username):
        user = User.query.filter_by(username=username).first_or_404()
        posts = user.posts.order_by(Post.publish_date.desc()).all()
        recent, top_tags = sidebar_data()
        return render_template('user.html', user=user, posts=posts, recent=recent, top_tags=top_tags)

    @app.route('/posts_by_tag/<string:tag_name>', methods=['GET'])
    def posts_by_tag(tag_name):
        tag = Tag.query.filter_by(title=tag_name).first_or_404()
        posts = tag.posts.order_by(Post.publish_date.desc()).all()
        recent, top_tags = sidebar_data()
        return render_template('tag.html', tag=tag, posts=posts, recent=recent, top_tags=top_tags)

    admin.add_view(ModelView(User, db.session))
    admin.add_view(ModelView(Post, db.session))
    admin.add_view(ModelView(Tag, db.session))
    admin.add_view(ModelView(Comment, db.session))

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
